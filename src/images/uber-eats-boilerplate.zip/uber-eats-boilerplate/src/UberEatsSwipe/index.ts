export { default } from "./UberEatsSwipe";

export const assets = [require("./assets/map.png")];
