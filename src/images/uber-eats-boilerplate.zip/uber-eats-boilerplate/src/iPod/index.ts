export { default } from "./iPod";
export const fonts = {
  Chicago: require("./assets/Chicago.ttf"),
};
