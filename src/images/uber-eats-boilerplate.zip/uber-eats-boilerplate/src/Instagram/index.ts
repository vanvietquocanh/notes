export { default } from "./Instagram";
