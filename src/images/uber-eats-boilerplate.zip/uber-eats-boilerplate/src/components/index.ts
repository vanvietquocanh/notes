export { default as LoadAssets } from "./LoadAssets";
export { default as StyleGuide } from "./StyleGuide";
export const assets = [require("./assets/mask.png")];
